let resumeData = {

    "name": "Sanjana S Pillai",
    "role": "Frontend Developer and Data Scientist",
    "linkedinId": "Your LinkedIn Id",
    "skypeid": "Your Skype Id",
    "roleDescription": "I am passionate about frontend development and data science, always eager to learn new technologies, work on impactful projects, and contribute to the tech community.",
    "socialLinks": [{
        "name": "linkedin",
        "url": "https://www.linkedin.com/in/sanjana-s-pillai/",
        "className": "fa fa-linkedin"
    },
    {
        "name": "github",
        "url": "https://github.com/Sanj5",
        "className": "fa fa-github"
    }
    ],
    "aboutme": "I am a second-year B.Tech student specializing in Artificial Intelligence and Data Science at Sri Eshwar College of Engineering. I’m passionate about software development, particularly frontend technologies and machine learning. My experiences in hackathons and real-world projects have honed my problem-solving skills and fostered teamwork. I am committed to continuous learning and staying updated with the latest industry trends. My goal is to contribute to innovative AI and data science projects that solve real-world problems and make a positive impact.",


    "education": [{
        "UniversityName": "Sri Eshwar College of Engineering",
        "specialization": "B.Tech in Artificial Intelligence and Data Science",
        "MonthOfPassing": "Ongoing",
        "YearOfPassing": "2027",
        "Achievements": "CGPA: 8.4 (Semester 2)"
    },
    {
        "UniversityName": "Kendriya Vidyalaya Wellington",
        "specialization": "HSC",
        "MonthOfPassing": "March",
        "YearOfPassing": "2023",
        "Achievements": "Percentage: 93.8%"
    },
    {
        "UniversityName": "Holy Innocents School and Junior College",
        "specialization": "SSLC",
        "MonthOfPassing": "March",
        "YearOfPassing": "2021",
        "Achievements": "Percentage: 92.5%"
    }
    ],

    "skillsDescription": "Technical skills acquired over time",
    "skills": [
        { "skillname": "Dart" },
        { "skillname": "Python" },
        { "skillname": "C" },
        { "skillname": "C++" },
        { "skillname": "Java" },
        { "skillname": "HTML" },

        { "skillname": "JavaScript" },
        { "skillname": "Flutter" },
        { "skillname": "DBMS" },
        { "skillname": "DSA" },
        { "skillname": "OOPS" },
        { "skillname": "MySQL" },
        { "skillname": "VSCode" },
        { "skillname": "Canva" },
        { "skillname": "GitHub" }
    ],
    "portfolio": [{
        "name": "Online Voting System",
        "description": "A secure and efficient console-based voting system designed to streamline the electoral process in educational or organizational settings.",
        "features": [
            "User-friendly interface for candidate selection",
            "Secure vote encryption to ensure confidentiality",
            "Real-time tally updates with detailed result visualization",
            "Error-handling and input validation for robustness"
        ],
        "techStack": ["C"],
        "imgurl": "https://blogs.microsoft.com/wp-content/uploads/prod/sites/5/2023/11/GettyImages-1165687569-scaled.jpg",
        "github": "https://github.com/Sanj5/Online-Voting-Application-using-C.git"
    },
    {
        "name": "Resume Score using NLP",
        "description": "An AI-powered resume analysis tool that evaluates resumes based on job descriptions, helping recruiters make informed hiring decisions.",
        "features": [
            "Keyword extraction using NLP techniques",
            "Customizable scoring model for job relevance",
            "Streamlit web interface for real-time uploads",
            "Accurate scoring with feature engineering"
        ],
        "techStack": ["Python", "Streamlit", "NLTK", "SpaCy", "Scikit-learn"],
        "imgurl": "https://www.theladders.com/wp-content/uploads/resume-190916.jpg",
        "url": "https://github.com/Sanj5/Resume-Scoring-using-NLP.git"
    },
    {
        "name": "Thunai",
        "description": "A mentorship application designed to connect users with industry mentors, offering personalized guidance and skill development.",
        "features": [
            "AI-driven mentor matching based on user preferences",
            "Real-time interaction via chat and video calls",
            "Progress tracking with personalized learning paths",
            "Selected for the Smart India Hackathon among 200+ teams"
        ],
        "techStack": ["Flutter", "Python", "REST API"],
        "imgurl": "images/portfolio/logo.png ",
        "url": "https://github.com/DemonGaming000/THUNAI"
    },
    {
        "name": "Text Summarizer",
        "description": "An NLP-based tool utilizing transformer models to generate concise and contextually accurate summaries of lengthy documents.",
        "features": [
            "Implemented T5 transformer model for high-accuracy summaries",
            "Preprocessing and feature extraction using Python libraries",
            "Evaluation through ROUGE scoring for performance validation",
            "User-friendly interface for text input and summary output"
        ],
        "techStack": ["Python", "SpaCy", "Hugging Face Transformers", "Scikit-learn"],
        "imgurl": "https://www.freecodecamp.org/news/content/images/2024/02/summary-1.jpeg",
        "url": "https://github.com/Sanj5/Text-Summarizer.git"
    }
    ],

    "testimonials": [{
        "description": "Secured 1st position in Self-E Hackathon at Sri Eshwar College of Engineering",
        "name": "Hackathon Organizer"
    },
    {
        "description": "Selected for WE Scholar Cohort 6, supported by Google, among top 220 students from 30,000 applicants.",
        "name": "TalentSprint Representative"
    }
    ]
}

export default resumeData;