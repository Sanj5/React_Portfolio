w // const readline = require("readline")
// const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout

// })
// let variable = ""

// rl.question("Enter your name: ", (data) => {
//     variable = data
// })
// console.log(variable);

// const os = require("os")
//     // console.log(os.homedir)
//     // console.log(os.cpus())
//     // console.log(os.arch())
//     // console.log(os.platform())
//     // console.log(os.hostname())
//     // console.log(os.version())
//     // console.log(os.version())

// console.log(os.freemem())
// console.log(os.totalmem())

const path = require("path")

console.log(__dirname)
console.log(__filename)
console.log(path.basename("C: \Users\ sanja\ Desktop\ winter_internship\ MERN\ server\ userInput.js"))
console.log(path.extname('sample.txt'))
console.log(path.join("folder", "userInput.js"))
console.log(path.parse("C: userInput.js"))