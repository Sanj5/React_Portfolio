// const server = require("http");
// const fs = require("fs");
// const url = require("url");

// server.createServer((req, res) => {
//     let { query } = url.parse(req.url, true);
//     console.log(query.id);
//     let { id, name } = query;
//     console.log(id);
//     console.log(name);

//     fs.readFile("index.html", "utf8", (err, data) => {
//         if (err) {
//             res.writeHead(500, { "Content-Type": "text/plain" });
//             res.end("Error reading the file.");
//         } else {
//             res.writeHead(200, { "Content-Type": "text/html" });
//             res.end(data);
//         }
//     });

//     res.end("hello");
// }).listen(3000, () => {
//     console.log("server is running");
// });


// // const currentDateTime = new Date().toLocaleString();

// // // fs.writeFileSync("task.txt", "", () => {})

// // fs.appendFile('task.txt', `${currentDateTime}\n`, (err) => {
// //     if (err) {
// //         console.error('Error writing to file:', err);
// //     } else {
// //         console.log(`Appended current date and time: ${currentDateTime}`);
// //     }
// // });



const http = require("http")
const { json } = require("stream/consumers")
const fs = require("fs")
const jsonData = fs.readFileSync("product.json", "utf-8")
console.log(jsonData)
const htmll = fs.readFileSync("index.html", "utf-8")
const server = http.createServer((req, res) => {
    //res.writeHead(200, { "content-type": "application/json" })
    //res.end(jsonData)
    let path = req.url
    if (path == '/home' || path === '/"') {
        res.end(htmll)
    } else if (path == '/about') {
        res.end("about")
    } else if (path == '/contact') {
        res.end("contact")
    } else if (path == '/products') {
        res.end("products")
    }
    console.log(req.url)

})
server.listen(3000, () => {
    console.log("http://127.0.0.1:3000")
})