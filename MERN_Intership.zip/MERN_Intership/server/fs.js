// const fs = require("fs")
//     //fs.writeFile("sample.txt", "created a new file using fs", (err) => {})

// //fs.appendFile("sample.txt", "\nAppended a file ", () => {})
// // fs.readFile("sample.txt", (err, data) => {
// //     console.log(data.toString())
// // })
// fs.unlink("sample.txt", () => {})

const fs = require("fs");

// fs.readFile("sample.tt", (err, data) => {
//     if (err) {
//         //throw err;
//     }
//     console.log(data.toString());
// });

// process.on("uncaughtException", (err) => {
//     console.log("An error occurred:", err.message);
// });

// fs.mkdir("folder", (err) => {})
// fs.rmdir("folder", (err) => {})

// fs.readFile("sample1.txt", (err, data) => {
//     console.log(data.toString())
// })
// console.log("Outside read file")

const fileData = fs.readFileSync("sample1.txt", "utf-8")
console.log(fileData);
fs.writeFile("sample.txt", fileData, (err) => {
    fs.appendFile("sample.txt", "first append", () => {
        fs.readFile("sample.txt", "utf-8", (err, data) => {
            console.log(data);
        })
    })
})

console.log("outside");