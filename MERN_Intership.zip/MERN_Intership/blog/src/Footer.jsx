import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';

function Footer() {
  return (
    <div class="bg-secondary"></div>
  )
}

export default Footer