package com.finalproject.javaCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
