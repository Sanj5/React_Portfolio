package com.finalproject.javaCrud.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("customer")
public class Cust {
    @Id
public String id;
    public String Name;
    public String Age;

}
