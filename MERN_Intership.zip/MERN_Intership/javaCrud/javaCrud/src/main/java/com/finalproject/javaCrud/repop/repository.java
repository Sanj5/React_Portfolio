package com.finalproject.javaCrud.repop;

import com.finalproject.javaCrud.model.Cust;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface repository extends MongoRepository<Cust,String> {
}
