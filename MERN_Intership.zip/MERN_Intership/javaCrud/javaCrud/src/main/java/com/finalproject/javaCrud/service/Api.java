package com.finalproject.javaCrud.service;

import com.finalproject.javaCrud.model.Cust;
import com.finalproject.javaCrud.repop.repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
@RestController
public class Api    {
    @Autowired
    repository repo;

    @GetMapping("/api/v1/spring")
    public Map<String,String> gerHtml(){
        Map<String,String> map = new HashMap<>();
        map.put("data","value");
        return map;
    }

    @PostMapping("/api/v1/cust")
    public Cust postData(@RequestBody Cust cust){
        return repo.save(cust);
    }
    @GetMapping("/api/v1/cust")
    public List<Cust> getData(){
        return repo.findAll();
    }
    @GetMapping("/api/v1/cust/{Id}")
    public Cust getDataById(@PathVariable String Id){
        return repo.findById(Id).get();
    }

    @PutMapping("/api/v1/cust/{Id}")
    public String updateData(@PathVariable String Id,@RequestBody Cust cust){

        Cust oldData= repo.findById(Id).get();
        oldData.Name=cust.Name;
        oldData.Age=cust.Age;
        repo.save(oldData);
        return "done";
    }


    @DeleteMapping("/api/v1/cust/{Id}")
    public String deleteData(@PathVariable String Id,@RequestBody Cust cust){
        repo.deleteById(Id);
        return "done";
    }

}
