export const Comp1 = () =>{
    return(
        <div> <p> Component 1</p></div>
    );
};


export function Comp2() {
  return (
    <div>Content</div>
  );
};


export function Comp3() {
  return (
    <div>Content</div>
  );
};


export function Comp4() {
    return (
      <div>Content</div>
    )
  }
  
 
  
export function Comp5() {
    return (
      <div>Content</div>
    )
  }
  
  