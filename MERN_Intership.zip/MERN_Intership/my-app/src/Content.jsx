//  import React from 'react'
 
 
 
//  function Content(prop) {
//   console.log();
//   // function handleClick(msg){
//   //   alert(msg)
//   // }
//   return(
//         // <div>
//         // <div>
//         //    <h1>Content</h1>
//         //    <p>Welcome to  the content page</p>
//         // </div>
       
        

//         // </div>
//         <div>
//           {/* <button onClick = {() => handleClick("You clicked the button")}>Click Me!!!</button> */}
//           {
//             prop.pData
//           }
          
//         </div>
//     )
// }

// export default Content;


// function Content({pData}){
//   let cData= "this data is from the child"
//   function handleClick(){
//     pData(cData)
//   }
//   return(
//     <div>
//       <button onClick = {handleClick}>submit</button>

//     </div>
//   )
// }
// export default Content;


// function Content({pData}) {
//     let cData = "this is data from the child";
//     function handleClick(){
//         pData(cData);
//     }
//     // let styleObj = {background:"red"};
//     // return (
//     //     <>
//     //         <button style ={styleObj}onClick = {handleClick}>Click me</button>
//     //     </>
//     // );
//     let styleObj = {background:"red"};
//     let tags = (
//         <div style ={styleObj}onClick = {handleClick}>
//             <h1>Example</h1>
//         </div>
//     )
//     return (
//        <>
//         {tags}
//        </>
//     );
// }

// export default Content;



