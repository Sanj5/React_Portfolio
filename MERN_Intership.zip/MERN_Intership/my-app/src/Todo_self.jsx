import React, { useRef, useState } from 'react';

function Todo() {
  const [data, setData] = useState([]); // Array to store tasks
  const refer = useRef(); // Reference for the input field

  function handleClick() {
    const task = refer.current.value.trim(); // Trim to remove extra spaces
    if (task) {
      // Prevent adding empty tasks
      setData([...data, { id: Math.random(), task }]); // Add task with unique id
      refer.current.value = ''; // Clear input field after adding
    }
  }

  return (
    <div>
      <h1>Todo App</h1>
      <input ref={refer} type="text" placeholder="Enter a task" />
      <button onClick={handleClick}>Save</button>
      <ul>
        {data.map((i) => (
          <li key={i.id}>{i.task}</li> // Displaying tasks with unique key
        ))}
      </ul>
    </div>
  );
}

export default Todo;
