// const Header = () => {
//     return (
//         <div>
//         <div>
//             <ul>
//                 <li>Home</li>
//                 <li>Products</li>
//                 <li>Contact</li>
//             </ul>
//         </div>
       
        

//         </div>
//     );
// };

// // export default Header;
// const Header = () => {
//     let data = [1, 2, 3, 4, 5];
    
//     return (
//       <div>
//         {
//           data.map((i) => (
//             <p key={i}>Number: {i}</p>
//           ))
//         }
//       </div>
//     );
//   };
  
//   export default Header;

// import React from 'react'

// const Header = () => {

//     let data = []
//     return(
//         <>
//         {
//         /* {!data.length > 0 && <h1> yeh it's</h1>
//         }*/
//         }
//         {
//             data.length >= 0 ? <h1>yes there is data </h1>:<h1> no more data</h1>
//         }
//         </>
//     )
// }
// export default Header;
//     if(true){
//   return (
//     <h1> It's for client</h1>
//   )
// }
// else{

// }
// let data = [{id: 1, userName: "jhon"}]
// return(
//     <>
//     {data.length > 0 && <h1> Yeh its an object</h1>

// }</>
// )
// }

// export default Header



//20January
import React from "react";


function Header() {
    // console.log("currying");
    // function curry(a){
    //     return (b) =>{
    //         console.log(a+b)
    //     }
    // }
    // curry(10)(20)


    // const curry = (a) => (b) => a+b;
    // console.log(curry(10)(40));

    function greet(greeting, symbol){
        const {name, age} = this
        console.log(name, age)
    }
   const user = {name:"John", age:27}
   greet.call(user, "hello", "!")
    
  return (
    <div>
         

    </div>
  )
}

export default Header


  


