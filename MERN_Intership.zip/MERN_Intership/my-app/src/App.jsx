// import React from "react"
// import {Header} from "./Header"
// import {Footer} from "./Footer"
// import {Content} from "./Content"
// import Component1 from "./Components"
// import {Component2,Component3,Component4,Component5} from "./Components"
// import {ApiCall} from "./ApiCall"
// import ToDo from "./ToDo"
// import { BrowserRouter, Routes, Route} from "react-router-dom"
// import { useParams } from "react-router-dom"
// import Home from "./Home"
// import About from "./About"
// import Contact from "./Contact"
// import OldBook from "./OldBook"
// import NewBook from "./NewBook"
// import User from "./User"
// import { Link } from "react-router-dom"
// function App() 
// {
  
//   // function getData(data)
//   // {
//   //   console.log(data)
//   // }
//   return (
//     <>
    
      
//       <BrowserRouter>
//       {/* <ul>
//       <li><Link to = '/home'>Home</Link></li>
//       <li><Link to = '/about'>About</Link></li>
//       <li><Link to = '/contact'>Contact</Link></li>
//       <li><Link to = '//user/:id'></Link></li>
//     </ul> */}
//       <Routes>
//         <Route path = '/home' element = {
//           <Home/>
//         }/>

//         <Route path = '/about' element = {
//           <About/>
//         }/>

//         <Route path = '/contact' element = {
//           <Contact/>
//         }/>
//         <Route path = '/books'>
          
//         <Route path = 'newbooks' element = {
//           <NewBook/>}/>
//           <Route path = 'oldbooks' element = {
//             <OldBook/>}/>

//         </Route>

//         <Route path = '/user/:id' element = {<User/>}/>
//           </Routes>
//           </BrowserRouter>
//     </>
//     )
// }
// export default App

import React from 'react'

import Counter from './counter/counter'
function App() {
  return (
    <div>
    <Counter/>
    </div>

    
    
  )
}

export default App