import React from 'react';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

function User() {
    const routeParam = useParams(); // Access URL parameters
    console.log(routeParam); // Logs route parameters for debugging
    const navigate = useNavigate();
    
    function handleClick() {
        navigate("/home"); // Navigate to the "/home" route
    }
    
    return (
        <div>
            User: {routeParam.id} {}            <button onClick={handleClick}>Home</button>
        </div>
    );
}

export default User;
