import React from 'react'
import { useState } from 'react';
function Form() {
  const [data, setData]= useState({email:"example@gmail.com", pass:""})
  function handleChange(e){
    setData({...data, email:e.target.value});
    

  }
  console.log(data)
  return (
  
   <div className="bg-blue-300 min-h-screen flex items-center justify-center">
        
        <form action = "" >
        <div className = 'p-1'>
            <label htmlFor = "">Email</label>
            </div>
            <div className = ' border border-black '>
            <input value = {data.email} onChange = {(e) => handleChange(e)} type = "text"/>
            </div>
            <br/>
            <br/>
            <div className = 'p-1'>
            <label htmlFor = "">Password</label>
            </div>
            <div className = ' border border-black '>
            <input type = "password"/>
            </div>
            <br/>
            
            <div className = 'bg-white m-8 w-20 align -items: center'>
            <button className="text-center px-4 py-2">
  Submit
</button>


            </div>
        </form>
    </div>
    
    )
    }

export default Form