// import { StrictMode } from 'react'
// import { createRoot } from 'react-dom/client'
// import './App.css'
// import App from './App.jsx'
// import MyContext from './ContextApi.jsx'

// let data = "global data"
// createRoot(document.getElementById('root')).render(
//   <MyContext.Provider value ={data}>
//     <App/>
//   </MyContext.Provider>
// )

import { createRoot } from "react-dom/client"; 
import App from "./App";
import { Provider } from "react-redux";
import store from "../reduxStore/store";
createRoot(document.getElementById('root')).render(
  <Provider store={store}>
    <App />
  </Provider>
)