// import React from 'react'
// import { useState , useRef } from 'react'
// import { useContext } from 'react';
// import MyContext from './ContextApi';
// import { use } from 'react';
// function Footer() {
//    const refer = useRef()
//    const [data , setData] = useState(0);
//    function handleClick() {
//    console.log(refer.current.value)
//    }

//    let dataFromGlobal = useContext(MyContext)
    
//   return (
//     <div>
//         {dataFromGlobal}
        
//         <input ref ={refer}
//         type="text"/>
//         <button onClick = {handleClick}> focus</button>

//     </div>
   
//   )
// }

// export default Footer




