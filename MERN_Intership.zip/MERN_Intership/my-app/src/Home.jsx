import React from 'react'
import Form from './Form'

function Home() {
  return (
    // <div> 
    //     {/* <h1 className = 'bg-teal-400 w-10 h-20 font - serif text-purple-500 underline decoration-orange-50 rounded-lg ring-1 border-2 border-red-500 shadow-md shadow-orange-600'>Hello h1</h1> */}

    // </div>
    // <div className = 'lg:bg-pink-500 md:bg-yellow-500 sm:bg-red-400'>
    //     Hello world
    // </div>
    <Form/>
  )
}

export default Home