import React, { useState, useRef } from 'react';

function Todo() {
    const [data, setData] = useState([]);
    const refer = useRef();

    function handleClick() {
        
        setData([...data, { task: refer.current.value }]);
        refer.current.value = ""; 
    }

    return (
        <div>
            <input ref={refer} type="text" />
            <button onClick={handleClick}>Save</button>
            <ul>
                {data.map((i, index) => (
                    <li key={index}>{i.task}</li>
                ))}
            </ul>
        </div>
    );
}

export default Todo;