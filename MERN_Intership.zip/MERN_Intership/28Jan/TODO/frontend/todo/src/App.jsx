import React from 'react'
import Task from './Task'

function App() {
  
  return (
    <div>
      <Task/>
    </div>
  )
}

export default App