const express = require('express')
const cors = require('cors')
const app = express()

const DB = require('./DB/db')
const courseSchema = require('./model/schema')

app.use(cors())
app.get("/api/v1/search", async(req, res) => {
    await DB()
    let query = req.query.search
    let course = await courseSchema.find({ title: { $regex: query, $options: "i" } })
    console.log(query)
    res.json(course)
})
app.listen(3000, () => {
    console.log('Server is running')
})