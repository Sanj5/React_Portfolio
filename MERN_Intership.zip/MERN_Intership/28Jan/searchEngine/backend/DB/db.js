const mong = require('mongoose')
async function DB() {
    try {
        await mong.connect('mongodb://localhost:27017/course')
        console.log("database connected");
    } catch (err) {
        console.log("database not connected");

    }
}
module.exports = DB