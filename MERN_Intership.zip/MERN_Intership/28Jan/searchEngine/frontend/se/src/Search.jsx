import React, {useState} from 'react'
import Views from './Views'
import axios from "axios"
function Search() {
  const [value, setValue] = useState("")
  const [data, setData] = useState([])
  async function handleViews(){
    let res = await axios.get(`http://localhost:3000/api/v1/search?search=${value}`)
   setData(res.data)
  }
  function handleClick(e){
    e.preventDefault()
    
    handleViews()
  }
  return (
    <div>
      <form action = "">
        <input value = {value} onChange = {(e) =>setValue(e.target.value)} type = "text"/>
        <button onClick = {(e)=>handleClick(e)}>Search</button>
      </form>
      {
        data.map((i) =><Views title={i.title } description={i.description } />)
      }
      
    </div>
  )
}

export default Search