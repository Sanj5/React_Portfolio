import React from 'react'
import Search from './Search'

function App() {
  return (
   <Search/>
  )
}

export default App