// Create a button dynamically
const button = document.createElement('button');
button.textContent = 'Click Me!'; // Set button text

// Attach an onClick event listener
button.addEventListener('click', () => {
    alert('Button was clicked!');
    button.removeEventListener('click', this);
    console.log("Button removed") // Remove the event listener
});

// Append the button to the container
document.getElementById('button').appendChild(button);