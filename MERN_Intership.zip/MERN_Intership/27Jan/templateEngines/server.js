const express = require("express")
const app = express()
const path = require('path')
const {engine} = require("express-handlebars")
app.use(express.static(path.join(__dirname, "public")))

app.engine("hbs", engine({extname : "hbs", defaultLayout :false}))
app.set("view engine", "hbs")

app.get('/home', (req, res)=>{
    const datachunk = "Sandhya"
    let array = [1,2,3,4,5]
    res.render("index", {datachunk, array})
})

app.get('/contact', (req, res)=>{
    res.render("contact")
})

app.get('/about', (req, res)=>{
    let array = [1,2,3,4,5]
    res.render("about", {array})
})


app.listen(3000, ()=> console.log("Server is running"))