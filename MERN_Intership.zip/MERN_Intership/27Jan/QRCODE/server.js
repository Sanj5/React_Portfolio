const express = require("express");
const qrcode = require("qrcode");
const path = require("path");
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/home", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"));
});

app.post("/qr", async(req, res) => {
    let link = req.body.data;
    if (!link || typeof link !== "string") {
        return res.status(400).json({ error: "Invalid input: String required" });
    }
    try {
        let genQr = await qrcode.toDataURL(link);
        res.json(genQr);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to generate QR code" });
    }
});

app.get("/qr", async(req, res) => {
    let link = req.query.link;
    if (!link || typeof link !== "string") {
        return res.status(400).json({ error: "Invalid input: String required" });
    }
    try {
        let genQr = await qrcode.toDataURL(link);
        res.json(genQr);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to generate QR code" });
    }
});

app.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});