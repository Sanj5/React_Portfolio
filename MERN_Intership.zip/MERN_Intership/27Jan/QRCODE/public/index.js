let link = document.getElementById("link");
let btn = document.getElementById("btn");
let toDisplay = document.getElementById("qrCode");

btn.addEventListener("click", (e) => {
    e.preventDefault();
    if (link.value) {
        getqrCode();
    } else {
        console.log("error: no input provided");
    }
});

async function getqrCode() {
    try {
        let response = await fetch(`http://localhost:3000/qr?link=${encodeURIComponent(link.value)}`);
        response = await response.json();
        console.log(response);
        let img = document.createElement("img");
        img.src = response; // Base64 image data from server
        toDisplay.innerHTML = "";
        toDisplay.append(img);
    } catch (error) {
        console.error("Error fetching QR code:", error);
    }
}