// function updateTime() {
//     const now = new Date();
//     const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
//     document.getElementById("time").value = time;
// }
// setInterval(updateTime, 1000);

// // Call the function to update the input box
// updateTime();
let i = 1;

function count() {
    const button = document.querySelector('#button1');
    button.innerHTML = 'Button clicked ' + i + ' times';
    i++;
}

const button = document.querySelector('#button1');
button.addEventListener('click', count);