/*const sayHello = () => {
    setTimeout(() => {
        console.log("hello")
    }, 5000);
}

const sayBye = () => {
    console.log("Bye");
}

sayHello();
sayBye();
let i = 0;
const interval = setInterval(() => {
    console.log("hello world");
    i++;
    if (i == 3)
        clearInterval(interval)
}, 3000)*/



// let takeTicket = new Promise((resolve, reject) => {
//     if (true) {
//         resolve("YES BOOKED");
//     } else {
//         reject("NOT YET BOOKED")
//     }
// })
// takeTicket.then((e) => {
//     console.log(e);

// }).catch((err) => {
//     console.log(err);

// })
// let takeTicket1 = new Promise((resolve, reject) => {
//     if (false) {
//         resolve("YES BOOKED");
//     } else {
//         reject("NOT YET BOOKED")
//     }
// })
// Promise.all([takeTicket, takeTicket1]).then((e) =>
//     console.log(e)).catch((e) =>
//     console.log(e))
// Promise.allSettled([takeTicket, takeTicket1]).then((e) =>
//     console.log(e)).catch((err) => console.log(err))

// const data = () => {
//     const response = fetch('https://jsonplaceholder.typicode.com/todos/1')
//     return response;
// }
// data().then((e) => {
//     console.log(e);
//     console.log(e.json());
// }).catch((e) => {
//     console.log(e)
// })

const data = async() => {
    let response = await fetch('https://jsonplaceholder.typicode.com/todos/1')
    response = await response.json()
    console.log(response);
}
data()