function playGame(userChoice) {
    const choices = ["Rock", "Paper", "Scissors"];

    if (userChoice < 0 || userChoice >= choices.length || isNaN(userChoice)) {
        console.log("Invalid choice! Please choose 0 for Rock, 1 for Paper, or 2 for Scissors.");
        return;
    }

    const computerChoice = Math.floor(Math.random() * 3);
    console.log(`You chose: ${choices[userChoice]}`);
    console.log(`Computer chose: ${choices[computerChoice]}`);

    const result =
        userChoice === computerChoice ?
        "It's a tie!" :
        (userChoice === 0 && computerChoice === 2) ||
        (userChoice === 1 && computerChoice === 0) ||
        (userChoice === 2 && computerChoice === 1) ?
        "You win!" :
        "You lose!";

    console.log(result);
}

// Play the game
playGame(0);