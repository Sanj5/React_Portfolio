/*var data = "value"; //string
data = true; //boolean
data = [1, 2, 3, 4]; //array
data = { key: 1 }; //object
console.log(data)

var isString = "          hello there                         ";
console.log(typeof isString);
console.log(isString.length);
console.log(isString.split(""));
isString = isString.trim()
console.log(isString);
console.log(isString.length);
console.log(isString.charAt(0));
console.log(isString[0]);
console.log(isString.indexOf('l'));
console.log(isString.lastIndexOf('l'));
console.log("str" + "1");


var newVar = 123;
console.log(typeof "" + newVar);
console.log(typeof `${ newVar}`);


var newvar1 = `sanjanaaaaaa
SVGFEDiffuseLightingElementsdefrg
dcfrghjuytrewqfghygfrgbvfdrer4t5hyu${newVar}`

console.log(newvar1);

var numHolder = 123.45;
//console.log(Number.parseInt(numHolder));

var strHolder = "123";
console.log(typeof Number(strHolder));
console.log(typeof + strHolder);



var intValue = 123.4;
console.log(Math.round(intValue))
console.log(Math.ceil(intValue))
console.log(Math.floor(intValue))
console.log(Math.min(1, 2, 3, 0));
console.log(Math.random() * 100)
console.log(Number.parseInt(Math.random() * 100))
console.log(Math.abs(-123))
console.log(Math.sqrt(9));
console.log(Math.cbrt(27));


var booleanVar = false
console.log(booleanVar);
var dataType = null;
console.log(dataType);


//arrays in java script

var arr = [1, "str", { obj: 1 }];
arr.push(3)
console.log(arr);

var dataVar = "hello";
dataVar = dataVar.split("");
dataVar = dataVar.reverse();
dataVar = dataVar.join("")
console.log(dataVar)

var i = 5;
while (i > 0) {
    console.log(i);
    i++;
}

["apple", "orange", "pineapple", "mango"].forEach((i, k) => {
        console.log(k, i);
    }) 
function sayHello() {
    console.log("Hello world");
}
sayHello();

function multiple(value1, value2) {
    return value1 * value2;
}
console.log(multiple(2, 3));

console.log(check);

var check = 10;

const addValue = (v1, v2) => {
    console.log(v1 + v2);
}
addValue(v1, v2);

const arrSum = (arr) => {
    let sum = 0
    for (var i = 0; i < arr.length; i++) {
        sum += arr[i];
    }
    return sum;
}

console.log(arrSum([2, 4, 6, 10]));


let arr = [1, 30, 10, 23];
let compute = arr.map(i => i + 1);
console.log(compute);
console.log(arr);

let compute1 = arr.filter(i =>
    i % 2 == 0);
console.log(compute1)

let compute2 = arr.map("even" =>
    i % 2 == 0);
console.log(compute1)*/

let testObj = {
    name: "John",
    age: 23
};
let { name: mo, age } = testObj;
console.log(mo, age)